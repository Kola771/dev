# Les prototypes
- Convertissez notre `class User` en fonctions et prototypes.
- Ne vous cassez pas la tête à ajouter l'âge.
